from office365.entity import Entity


class OutlookEntity(Entity):
    """Base Outlook entity."""
    pass
