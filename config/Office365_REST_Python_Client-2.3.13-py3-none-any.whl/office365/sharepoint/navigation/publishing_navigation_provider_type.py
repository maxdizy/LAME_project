class PublishingNavigationProviderType:
    def __init__(self):
        pass

    InvalidSiteMapProvider = 0
    PortalSiteMapProvider = 1
    TaxonomySiteMapProvider = 2
