from office365.runtime.client_value import ClientValue


class MenuNode(ClientValue):
    """Represents a navigation node in the navigation hierarchy. A navigation hierarchy is a tree structure of
    navigation nodes."""
    pass
