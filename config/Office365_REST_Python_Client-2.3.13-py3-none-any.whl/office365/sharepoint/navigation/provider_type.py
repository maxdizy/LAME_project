class NavigationProviderType:

    def __init__(self):
        pass

    SPNavigationProvider = "SPNavigationProvider"

    AdministrationQuickLaunchProvider = "AdministrationQuickLaunchProvider"

    SharedServicesQuickLaunchProvider = "SharedServicesQuickLaunchProvider"

    GlobalNavSiteMapProvider = "GlobalNavSiteMapProvider"

    CombinedNavSiteMapProvider = "CombinedNavSiteMapProvider"

    CurrentNavSiteMapProvider = "CurrentNavSiteMapProvider"

    CurrentNavSiteMapProviderNoEncode = "CurrentNavSiteMapProviderNoEncode"

    GlobalNavigation = "GlobalNavigation"

    CurrentNavigation = "CurrentNavigation"

    MySitePersonalQuickLaunchProvider = "MySitePersonalQuickLaunchProvider"

    MySiteHostTopNavigationProvider = "MySiteHostTopNavigationProvider"

    GlobalNavigationSwitchableProvider = "GlobalNavigationSwitchableProvider"

    CurrentNavigationSwitchableProvider = "CurrentNavigationSwitchableProvider"

    GlobalNavigationTaxonomyProvider = "GlobalNavigationTaxonomyProvider"

    CurrentNavigationTaxonomyProvider = "CurrentNavigationTaxonomyProvider"

    MySiteMapProvider = "MySiteMapProvider"

    MySiteLeftNavProvider = "MySiteLeftNavProvider"

    MySiteDocumentStaticProvider = "MySiteDocumentStaticProvider"

    MySiteSitesPageStaticProvider = "MySiteSitesPageStaticProvider"

    MySiteSubNavProvider = "MySiteSubNavProvider"

    EduTopNavProvider = "EduTopNavProvider"

    MySiteHostQuickLaunchProvider = "MySiteHostQuickLaunchProvider"
