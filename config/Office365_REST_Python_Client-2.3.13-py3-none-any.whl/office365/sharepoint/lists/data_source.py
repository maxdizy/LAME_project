from office365.runtime.client_value import ClientValue


class ListDataSource(ClientValue):
    """Stores the parameters required for a list to communicate with its external data source."""
