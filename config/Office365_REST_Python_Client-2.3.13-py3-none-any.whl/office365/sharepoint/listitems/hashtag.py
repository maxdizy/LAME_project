from office365.runtime.client_value import ClientValue


class Hashtag(ClientValue):
    pass
