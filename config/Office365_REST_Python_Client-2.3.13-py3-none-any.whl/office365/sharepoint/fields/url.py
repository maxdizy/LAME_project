from office365.sharepoint.fields.field import Field


class FieldUrl(Field):
    """Specifies a fields that contains a URL."""
    pass
