from office365.sharepoint.fields.field import Field


class FieldGeolocation(Field):
    """Specifies a field (2) that contains geographical location values.<190>
    The NoCrawl and SchemaXmlWithResourceTokens properties are not included in the default scalar property set
    for this type.
    """
    pass
