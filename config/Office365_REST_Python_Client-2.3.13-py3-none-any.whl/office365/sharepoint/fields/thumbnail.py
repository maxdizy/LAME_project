from office365.sharepoint.fields.field import Field


class FieldThumbnail(Field):
    pass
