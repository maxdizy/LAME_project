from office365.sharepoint.fields.field import Field


class FieldGuid(Field):
    """Specifies a field that contains global unique identifier values."""
    pass
