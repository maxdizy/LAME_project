class MoveOperations:
    """Specifies criteria for how to move files."""

    none = 0

    overwrite = 1
