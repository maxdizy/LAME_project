from office365.runtime.client_value import ClientValue


class SPClientSideComponentQueryResult(ClientValue):
    pass


class SPClientSideComponentIdentifier(ClientValue):
    """This identifier uniquely identifies a component."""
    pass
