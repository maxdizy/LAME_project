from office365.runtime.client_value import ClientValue


class DocumentSetContent(ClientValue):
    """Represents the default content of document set in SharePoint."""
    pass
