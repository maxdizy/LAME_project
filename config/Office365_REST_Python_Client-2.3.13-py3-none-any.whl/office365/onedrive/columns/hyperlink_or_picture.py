from office365.runtime.client_value import ClientValue


class HyperlinkOrPictureColumn(ClientValue):
    """Represents a hyperlink or picture column in SharePoint."""
    pass
