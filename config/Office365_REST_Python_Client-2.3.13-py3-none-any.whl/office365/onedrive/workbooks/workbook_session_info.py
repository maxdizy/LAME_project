from office365.runtime.client_value import ClientValue


class WorkbookSessionInfo(ClientValue):
    """Provides information about workbook session."""
    pass
