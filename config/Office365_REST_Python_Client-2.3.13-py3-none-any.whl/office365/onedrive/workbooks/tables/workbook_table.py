from office365.entity import Entity


class WorkbookTable(Entity):
    """Represents an Excel table."""
    pass
