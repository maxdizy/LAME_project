class ODataMethod(object):
    pass
