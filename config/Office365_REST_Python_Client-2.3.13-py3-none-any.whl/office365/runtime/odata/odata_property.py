class ODataProperty(object):

    def __init__(self):
        self.name = None
