class CredentialType:

    def __init__(self):
        pass

    None_ = 0
    Basic = 1
    Ntlm = 2
    Saml = 3
