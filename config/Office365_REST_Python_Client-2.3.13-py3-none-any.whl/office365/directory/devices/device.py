from office365.directory.directory_object import DirectoryObject


class Device(DirectoryObject):
    pass
