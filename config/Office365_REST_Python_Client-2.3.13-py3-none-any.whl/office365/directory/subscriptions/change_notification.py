from office365.runtime.client_value import ClientValue


class ChangeNotification(ClientValue):
    """Represents the notification sent to the subscriber."""
    pass
