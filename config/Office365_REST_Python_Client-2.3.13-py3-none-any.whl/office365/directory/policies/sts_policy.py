from office365.directory.policies.policy_base import PolicyBase


class StsPolicy(PolicyBase):
    pass
