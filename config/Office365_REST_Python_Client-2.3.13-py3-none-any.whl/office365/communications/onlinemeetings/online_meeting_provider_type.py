class OnlineMeetingProviderType:
    """Specifies the type of a principal."""

    def __init__(self):
        pass

    unknown = 0
    skypeForBusiness = 1
    skypeForConsumer = 2
    teamsForBusiness = 3
