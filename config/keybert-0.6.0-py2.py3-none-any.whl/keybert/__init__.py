from keybert._model import KeyBERT

__version__ = "0.6.0"
